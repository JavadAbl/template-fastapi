from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase, Session

from app.config import get_settings

settings = get_settings()

engine = create_engine(
    settings.database_url,
    connect_args={"check_same_thread": False},  # SQLite only
    echo=settings.debug,
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    """Base class for all ORM models — all models inherit from this."""
    pass


def create_tables() -> None:
    """Create all tables that are registered on Base.metadata.

    Call once during app startup (see main.py lifespan).
    Import all models *before* calling this so their tables are
    registered on Base.metadata.
    """
    # Ensure models are imported so Base.metadata knows about them
    import app.users.models  # noqa: F401

    Base.metadata.create_all(bind=engine)
