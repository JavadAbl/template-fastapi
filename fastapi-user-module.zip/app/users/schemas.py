from datetime import datetime

from pydantic import BaseModel, EmailStr, Field, field_validator


# ─── Auth Schemas ────────────────────────────────────────────────


class Token(BaseModel):
    """JWT token response."""

    access_token: str
    token_type: str = "bearer"


class TokenPayload(BaseModel):
    """Decoded JWT payload."""

    sub: str  # user id
    exp: datetime


class LoginRequest(BaseModel):
    """Credentials for obtaining a token."""

    username: str = Field(..., min_length=3, max_length=50)
    password: str = Field(..., min_length=8, max_length=128)


# ─── User Request Schemas ────────────────────────────────────────


class UserCreate(BaseModel):
    """Payload for creating a new user."""

    email: EmailStr
    username: str = Field(
        ...,
        min_length=3,
        max_length=50,
        pattern=r"^[a-zA-Z0-9_-]+$",
        description="Alphanumeric, underscores, and hyphens only.",
    )
    password: str = Field(
        ...,
        min_length=8,
        max_length=128,
        description="At least 8 characters.",
    )
    full_name: str | None = Field(None, max_length=150)

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        """Enforce minimum password complexity."""
        if not any(c.isupper() for c in v):
            raise ValueError("Password must contain at least one uppercase letter.")
        if not any(c.isdigit() for c in v):
            raise ValueError("Password must contain at least one digit.")
        return v


class UserUpdate(BaseModel):
    """Payload for partially updating an existing user."""

    email: EmailStr | None = None
    full_name: str | None = Field(None, max_length=150)
    bio: str | None = Field(None, max_length=1000)
    avatar_url: str | None = Field(None, max_length=500)
    is_active: bool | None = None


class UserPasswordChange(BaseModel):
    """Payload for changing the current user's password."""

    current_password: str = Field(..., min_length=8, max_length=128)
    new_password: str = Field(
        ...,
        min_length=8,
        max_length=128,
        description="At least 8 characters.",
    )

    @field_validator("new_password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        if not any(c.isupper() for c in v):
            raise ValueError("Password must contain at least one uppercase letter.")
        if not any(c.isdigit() for c in v):
            raise ValueError("Password must contain at least one digit.")
        return v


# ─── User Response Schemas ───────────────────────────────────────


class UserResponse(BaseModel):
    """Public user profile returned in API responses."""

    id: str
    email: str
    username: str
    full_name: str | None
    bio: str | None
    avatar_url: str | None
    is_active: bool
    is_superuser: bool
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class UserListResponse(BaseModel):
    """Paginated list of users."""

    items: list[UserResponse]
    total: int
    page: int
    size: int
    pages: int
