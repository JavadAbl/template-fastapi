"""User service — all business logic and database queries live here.

The router layer calls these functions; the service never imports from
the router, keeping the dependency direction clean.
"""

from math import ceil

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.users.models import User
from app.users.schemas import UserCreate, UserUpdate
from app.users.exceptions import (
    UserNotFoundException,
    UsernameAlreadyExistsException,
    EmailAlreadyExistsException,
    InvalidCredentialsException,
    InactiveUserException,
    WrongPasswordException,
)
from app.security import hash_password, verify_password


# ─── Read operations ─────────────────────────────────────────────


def get_user_by_id(db: Session, user_id: str) -> User:
    """Return a user by primary key or raise UserNotFoundException."""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise UserNotFoundException()
    return user


def get_user_by_username(db: Session, username: str) -> User | None:
    """Return a user by username or None."""
    return db.query(User).filter(User.username == username).first()


def get_user_by_email(db: Session, email: str) -> User | None:
    """Return a user by email or None."""
    return db.query(User).filter(User.email == email).first()


def list_users(
    db: Session,
    *,
    page: int = 1,
    size: int = 20,
    active_only: bool = False,
) -> tuple[list[User], int]:
    """Return a paginated list of users and the total count.

    Returns (users, total_count).
    """
    query = db.query(User)
    if active_only:
        query = query.filter(User.is_active.is_(True))

    total = query.count()
    users = (
        query.order_by(User.created_at.desc())
        .offset((page - 1) * size)
        .limit(size)
        .all()
    )
    return users, total


# ─── Create / Auth ────────────────────────────────────────────────


def create_user(db: Session, data: UserCreate) -> User:
    """Register a new user after checking for duplicate username / email."""
    if get_user_by_username(db, data.username):
        raise UsernameAlreadyExistsException(data.username)
    if get_user_by_email(db, data.email):
        raise EmailAlreadyExistsException(data.email)

    user = User(
        email=data.email,
        username=data.username,
        hashed_password=hash_password(data.password),
        full_name=data.full_name,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def authenticate_user(db: Session, username: str, password: str) -> User:
    """Verify credentials and return the user, or raise InvalidCredentialsException."""
    user = get_user_by_username(db, username)
    if not user or not verify_password(password, user.hashed_password):
        raise InvalidCredentialsException()
    if not user.is_active:
        raise InactiveUserException()
    return user


# ─── Update operations ───────────────────────────────────────────


def update_user(db: Session, user_id: str, data: UserUpdate) -> User:
    """Partially update a user's profile fields."""
    user = get_user_by_id(db, user_id)

    if data.email is not None and data.email != user.email:
        existing = get_user_by_email(db, data.email)
        if existing and existing.id != user_id:
            raise EmailAlreadyExistsException(data.email)
        user.email = data.email

    for field in ("full_name", "bio", "avatar_url", "is_active"):
        value = getattr(data, field, None)
        if value is not None:
            setattr(user, field, value)

    db.commit()
    db.refresh(user)
    return user


def change_password(
    db: Session,
    user_id: str,
    current_password: str,
    new_password: str,
) -> User:
    """Change the user's password after verifying the current one."""
    user = get_user_by_id(db, user_id)
    if not verify_password(current_password, user.hashed_password):
        raise WrongPasswordException()
    user.hashed_password = hash_password(new_password)
    db.commit()
    db.refresh(user)
    return user


# ─── Delete operation ────────────────────────────────────────────


def delete_user(db: Session, user_id: str) -> None:
    """Soft-delete by setting is_active=False, or hard-delete.

    Currently implements hard-delete. Switch to soft-delete by
    toggling the comment below.
    """
    user = get_user_by_id(db, user_id)

    # Hard delete:
    db.delete(user)

    # Soft delete (uncomment if preferred):
    # user.is_active = False

    db.commit()
