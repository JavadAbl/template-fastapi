"""Shared FastAPI dependency-injection providers.

These are the "glue" between the HTTP layer and the data / auth layer.
Every route that needs a DB session or the current user should declare
them via ``Depends(...)``.
"""

from fastapi import Depends
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database import SessionLocal
from app.security import decode_access_token
from app.users.models import User
from app.users.exceptions import (
    InvalidCredentialsException,
    InactiveUserException,
    NotSuperuserException,
)

settings = get_settings()

oauth2_scheme = OAuth2PasswordBearer(tokenUrl=f"{settings.api_v1_prefix}/users/login")


# ─── Database session ────────────────────────────────────────────


def get_db() -> Session:
    """Yield a DB session per request and close it when done."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ─── Current user ────────────────────────────────────────────────


def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> User:
    """Decode the JWT, look up the user, and ensure they are active."""
    try:
        payload = decode_access_token(token)
        user_id: str | None = payload.get("sub")
        if user_id is None:
            raise InvalidCredentialsException()
    except JWTError:
        raise InvalidCredentialsException()

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise InvalidCredentialsException()
    if not user.is_active:
        raise InactiveUserException()
    return user


def require_superuser(current_user: User = Depends(get_current_user)) -> User:
    """Guard that only superusers can pass."""
    if not current_user.is_superuser:
        raise NotSuperuserException()
    return current_user
