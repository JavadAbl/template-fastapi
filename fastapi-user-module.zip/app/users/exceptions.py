from fastapi import HTTPException, status


class UserNotFoundException(HTTPException):
    """Raised when a requested user cannot be found."""

    def __init__(self, identifier: str = "User") -> None:
        super().__init__(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"{identifier} not found.",
        )


class UsernameAlreadyExistsException(HTTPException):
    """Raised on registration when the username is already taken."""

    def __init__(self, username: str) -> None:
        super().__init__(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Username '{username}' is already registered.",
        )


class EmailAlreadyExistsException(HTTPException):
    """Raised on registration / update when the email is already taken."""

    def __init__(self, email: str) -> None:
        super().__init__(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Email '{email}' is already registered.",
        )


class InvalidCredentialsException(HTTPException):
    """Raised when login credentials are incorrect."""

    def __init__(self) -> None:
        super().__init__(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password.",
            headers={"WWW-Authenticate": "Bearer"},
        )


class InactiveUserException(HTTPException):
    """Raised when a disabled / inactive user attempts an action."""

    def __init__(self) -> None:
        super().__init__(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is inactive.",
        )


class NotSuperuserException(HTTPException):
    """Raised when a non-superuser tries to access an admin endpoint."""

    def __init__(self) -> None:
        super().__init__(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only superusers can perform this action.",
        )


class WrongPasswordException(HTTPException):
    """Raised when the current password provided for a password change is wrong."""

    def __init__(self) -> None:
        super().__init__(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Current password is incorrect.",
        )
