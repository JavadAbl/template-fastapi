"""User router — thin HTTP layer that delegates all logic to the service.

Responsibilities:
  - Parse & validate request bodies / query params (via Pydantic schemas)
  - Call service functions
  - Shape the response
  - Handle authentication / authorization guards
"""

from math import ceil

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.dependencies import get_db, get_current_user, require_superuser
from app.users import service
from app.users.models import User
from app.users.schemas import (
    Token,
    LoginRequest,
    UserCreate,
    UserUpdate,
    UserPasswordChange,
    UserResponse,
    UserListResponse,
)
from app.security import create_access_token
from app.users.exceptions import InactiveUserException

router = APIRouter(prefix="/users", tags=["users"])


# ─── Auth ────────────────────────────────────────────────────────


@router.post("/register", response_model=UserResponse, status_code=201)
def register(data: UserCreate, db: Session = Depends(get_db)) -> User:
    """Create a new user account."""
    return service.create_user(db, data)


@router.post("/login", response_model=Token)
def login(data: LoginRequest, db: Session = Depends(get_db)) -> dict:
    """Authenticate with username + password and receive a JWT."""
    user = service.authenticate_user(db, data.username, data.password)
    token = create_access_token(subject=user.id)
    return {"access_token": token, "token_type": "bearer"}


# ─── Current user profile ───────────────────────────────────────


@router.get("/me", response_model=UserResponse)
def read_current_user(current_user: User = Depends(get_current_user)) -> User:
    """Return the authenticated user's own profile."""
    return current_user


@router.patch("/me", response_model=UserResponse)
def update_current_user(
    data: UserUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> User:
    """Partially update the authenticated user's profile."""
    return service.update_user(db, current_user.id, data)


@router.put("/me/password", response_model=UserResponse)
def change_my_password(
    data: UserPasswordChange,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> User:
    """Change the current user's password."""
    return service.change_password(
        db,
        current_user.id,
        data.current_password,
        data.new_password,
    )


@router.delete("/me", status_code=204)
def delete_my_account(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> None:
    """Delete the authenticated user's own account."""
    service.delete_user(db, current_user.id)


# ─── Admin / user management ────────────────────────────────────


@router.get("", response_model=UserListResponse)
def list_users(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    active_only: bool = Query(False),
    db: Session = Depends(get_db),
    _admin: User = Depends(require_superuser),
) -> dict:
    """List all users (admin only). Supports pagination and active-only filter."""
    users, total = service.list_users(db, page=page, size=size, active_only=active_only)
    return {
        "items": users,
        "total": total,
        "page": page,
        "size": size,
        "pages": ceil(total / size) if total else 0,
    }


@router.get("/{user_id}", response_model=UserResponse)
def read_user(
    user_id: str,
    db: Session = Depends(get_db),
    _admin: User = Depends(require_superuser),
) -> User:
    """Get a single user by ID (admin only)."""
    return service.get_user_by_id(db, user_id)


@router.patch("/{user_id}", response_model=UserResponse)
def update_user(
    user_id: str,
    data: UserUpdate,
    db: Session = Depends(get_db),
    _admin: User = Depends(require_superuser),
) -> User:
    """Update any user by ID (admin only)."""
    return service.update_user(db, user_id, data)


@router.delete("/{user_id}", status_code=204)
def delete_user(
    user_id: str,
    db: Session = Depends(get_db),
    _admin: User = Depends(require_superuser),
) -> None:
    """Delete any user by ID (admin only)."""
    service.delete_user(db, user_id)
